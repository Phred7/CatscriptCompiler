package edu.montana.csci.csci468;

import edu.montana.csci.csci468.parser.ErrorType;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public class PartnersTest extends CatscriptTestBase {

}
