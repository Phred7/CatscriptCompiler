package edu.montana.csci.csci468.demo;

import java.util.Objects;

public class Scratch {
    public void main() {
        int z = testFoo(10, 20);
    }

    public int testFoo(int x, int y) {
        return x + y;
    }
}
