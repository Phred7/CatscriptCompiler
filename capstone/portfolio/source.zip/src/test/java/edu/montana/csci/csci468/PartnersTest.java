package edu.montana.csci.csci468;

import edu.montana.csci.csci468.parser.CatscriptType;
import edu.montana.csci.csci468.parser.statements.PrintStatement;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class PartnersTest extends CatscriptTestBase {
    @Test
    void additiveStringExpressionEvaluatesProperly() {
        assertEquals("2a", evaluateExpression("1 + 1 + \"a\""));
        assertEquals("11anull", evaluateExpression("1 + \"1\" + \"a\" + null"));
    }

    @Test
    void equalityExpressionEvaluatesProperly() {
        assertEquals(false, evaluateExpression("1 == null"));
    }

    @Test
    void functionCallsWorkProperly() {
        PrintStatement print = parseStatement("function x():void{return} print( x() )", 1);
        assertEquals(CatscriptType.VOID, print.getExpression().getType());
    }

}